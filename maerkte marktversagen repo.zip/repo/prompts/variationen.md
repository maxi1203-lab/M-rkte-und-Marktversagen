# Prompt: Variationen generieren

Erstelle Übungsaufgaben im Stil der echten HÜs und Probeklausur — mit anderen Zahlen aber gleicher Struktur.

## Wenn ich sage "Variation zu [Aufgabe]":

1. **Lies die Originalaufgabe** aus `content/`
2. **Behalte die Struktur** exakt bei (gleicher Aufgabentyp, gleiche Teilaufgaben)
3. **Ändere die Zahlen:**
   - Andere Koeffizienten in Nachfrage/Kostenfunktionen
   - Andere Wahrscheinlichkeiten bei Risiko-Aufgaben
   - Andere Payoffs in Spielmatrizen
   - Andere Grenzkosten, Fixkosten etc.
4. **Stelle sicher** dass die Aufgabe lösbar ist und sinnvolle Ergebnisse liefert (keine negativen Mengen, Q*>0, etc.)
5. **Kennzeichne als** 🔄 Variation
6. **Liefere die Lösung** direkt mit, Schritt für Schritt

## Wenn ich sage "Probeklausur simulieren":

Erstelle eine komplette Klausur im Format der Probeklausur:
- **Teil 1:** 6 Single-Choice-Aufgaben à 4 Punkte (mit je 5 Antwortmöglichkeiten)
- **Teil 2:** 3 offene Rechenaufgaben (ca. 8-10 Punkte je)
- Decke verschiedene Themengebiete ab
- Nutze die Aufgabentypen aus den echten HÜs
- **Zeitvorgabe:** 75 Minuten
- Liefere einen separaten Lösungsteil

## Wenn ich sage "Übe [Thema] mit mir":

Gib mir eine Aufgabe zum Thema, warte auf meine Antwort, und korrigiere sie dann.
- Sei ein strenger aber fairer Korrektor
- Gib Teilpunkte für richtige Ansätze
- Erkläre wo der Fehler liegt, wenn etwas falsch ist

## Schwierigkeitsgrade

Bei "leichte Variation": Einfache lineare Funktionen, kleine Zahlen
Bei "mittlere Variation": Wie in den HÜs (Standard-Klausurniveau)  
Bei "schwere Variation": Asymmetrische Kosten, quadratische TC, ungewöhnliche Nachfrage
