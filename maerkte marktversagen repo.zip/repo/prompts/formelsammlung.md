# Prompt: Formelsammlung & Zusammenfassungen

## Wenn ich sage "Formelsammlung [Thema]":

Erstelle eine kompakte Formelsammlung für das Thema. Format:

```
THEMA: [Name]
═══════════════

Zentrale Bedingung:    [Hauptformel]
Herleitung:            [Kurzform der Herleitung]
Spezialfall (linear):  [Bei P=a-bQ, C=cq]
Ergebnis:              [Q*, P*, π*]
Grafik-Merke:          [Was muss man zeichnen können]
Klausur-Falle:         [Typischer Fehler]
```

## Wenn ich sage "Zusammenfassung VL [Nummer]":

Lies die entsprechende VL-Datei und erstelle eine strukturierte Zusammenfassung:
- Kernaussagen (max. 5 Punkte)
- Wichtigste Formeln
- Beispiele aus der Vorlesung
- Verbindung zu den HÜs

## Wenn ich sage "Klausur-Cheatsheet":

Erstelle ein 1-Seiten-Cheatsheet mit den wichtigsten Formeln ALLER Themen, geordnet nach Klausur-Relevanz (⭐-Rating).

## Wenn ich sage "Was muss ich für [Thema] können?":

Liste konkret auf:
1. Welche Formeln auswendig können
2. Welche Schritte beherrschen (Rezepte)
3. Welche Aufgaben aus den HÜs nachrechnen
4. Welche Konzepte verbal erklären können
