# Prompt: Konzept erklären

Wenn ich nach einem Konzept frage, erkläre es so:

## Format

### 1. Definition (aus der Vorlesung)
Lies die relevante VL-Datei und gib die Definition wie Prof. Gantner sie verwendet.

### 2. Intuition
Erkläre in einfachen Worten, WARUM das so ist. Nutze Alltagsbeispiele.

### 3. Formal
Die mathematische Darstellung mit allen relevanten Formeln.

### 4. Graphisch
Beschreibe die grafische Darstellung (was ist auf welcher Achse, wo liegt das GGW, etc.)

### 5. Klausur-Bezug
- In welchen HÜs kam das vor?
- In welcher Form wurde es in der Probeklausur abgefragt?
- Typische Fehlerquellen

## Typische Fragen

```
Was ist der Lerner-Index?
Erkläre Rückwärtsinduktion
Was ist der Unterschied zwischen Nash-GGW und SPNE?
Warum ist Kollusion kein Gleichgewicht?
Was ist die Samuelson-Bedingung?
Wie funktioniert Signaling im Spence-Modell?
Was ist das Coase-Theorem?
Wann produziert ein Monopolist im elastischen Bereich?
```

## Vergleichs-Fragen

Bei "Vergleiche X und Y" (z.B. Cournot vs. Bertrand, Nash vs. SPNE):
- Gemeinsamkeiten
- Unterschiede
- Wann wird welches Modell verwendet?
- Ergebnis-Vergleich (Preis, Menge, Gewinn)
