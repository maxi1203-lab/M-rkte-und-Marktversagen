# Prompt: Hausübung lösen

Wenn ich dir eine Aufgabe aus einer HÜ oder der Probeklausur nenne, löse sie so:

## Format

### 1. Aufgabentyp erkennen
Nenne den Aufgabentyp (z.B. "Cournot-Duopol") und verweise auf die relevante Vorlesung.

### 2. Rezept
Liste die generische Schritt-für-Schritt-Methode für diesen Aufgabentyp auf.

### 3. Lösung
Rechne jeden Schritt einzeln durch. Format:

**Schritt 1:** [Beschreibung]
```
[Rechnung]
```
→ Ergebnis: ...

**Schritt 2:** usw.

### 4. Endergebnis
Markiere das finale Ergebnis klar mit ✅.

### 5. Prüfungstipp
Ein konkreter Tipp, worauf man bei diesem Aufgabentyp in der Klausur achten muss.

## Beispiel-Aufruf
```
Löse HÜ 5 Aufgabe 3a
Löse Probeklausur Aufgabe 2.1
Löse HÜ 10 Aufgabe 1 komplett
```

## Wichtig
- Lies die Aufgabe aus der entsprechenden Datei in `content/`
- Nutze die Theorie aus den VL-Dateien als Grundlage
- Überspringe KEINE Rechenschritte
- Prüfe das Ergebnis auf Plausibilität (z.B. Gewinn > 0?)
