# Märkte & Marktversagen — Lernrepo

**Universität Innsbruck · IWW-Bachelor · Prof. Dr. Anita Gantner**

Vollständiges Lernrepo für die Klausur-Vorbereitung. Enthält den gesamten Kursstoff als Textextrakte, optimiert für die Arbeit mit Claude Code.

## Inhalt

| Ordner | Inhalt | Dateien |
|--------|--------|---------|
| `content/VL_*.txt` | 9 Vorlesungen (Folienextrakte) | 9 |
| `content/HW*.txt` | 14 Hausübungen | 14 |
| `content/Probeklausur.txt` | Übungsklausur Gesamtprüfung | 1 |
| `prompts/` | Spezial-Prompts für verschiedene Lernmodi | 4 |
| `CLAUDE.md` | Haupt-Instruktion für Claude Code | 1 |

## Nutzung mit Claude Code

```bash
# Repo klonen / Dateien in Projektordner legen
# Dann in Claude Code:

claude   # startet Claude Code im Repo-Verzeichnis
```

Claude Code liest automatisch die `CLAUDE.md` und versteht den gesamten Kurskontext.

### Beispiel-Prompts

```
> Löse mir HÜ 5 Aufgabe 3 Schritt für Schritt
> Erkläre Cournot vs Bertrand mit den Zahlen aus der Probeklausur  
> Gib mir 3 Variationen zu Klausuraufgabe 1.6 (Risiko)
> Erstelle eine Zusammenfassung von VL 7 (Asymmetrische Information)
> Welche Aufgabentypen kommen am häufigsten in den HÜs vor?
> Simuliere eine Probeklausur mit neuen Zahlen
```

## Themenübersicht

1. **Monopol** — Gewinnmax., MR=MC, DWL, Regulierung, Preisdiskriminierung
2. **Simultane Spiele** — Nash-GGW, dominante Strategien, Gefangenendilemma
3. **Oligopol** — Cournot (Mengen), Bertrand (Preise), Reaktionsfunktionen
4. **Dynamische Spiele** — Spielbäume, Rückwärtsinduktion, SPNE, Stackelberg
5. **Wiederholte Spiele** — Trigger-Strategie, Kartelle, Diskontfaktor δ
6. **Risikoentscheidungen** — Lotterien, Erwartungsnutzen, CE, Risikoprämie
7. **Asymmetrische Information** — Moral Hazard, Adverse Selektion, Lemons, Signaling
8. **Öffentliche Güter** — Rivalität, Ausschließbarkeit, Samuelson, Free-Rider
9. **Externalitäten** — Pigou-Steuer, Coase-Theorem, Fusion, handelbare Zertifikate
